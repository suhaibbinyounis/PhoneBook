import mysql.connector
from tkinter import *
from mysql.connector import Error
connection = mysql.connector.connect(host='localhost',database='',user='root',password='',auth_plugin='mysql_native_password')
cursor= connection.cursor()
name=e1.get()
phone=e2.get()
query1 = "create table Books(BookID varchar(30),TitleID varchar(30),Location varchar(30),Genre varchar(30))"
query2 = "create table Titles(TitleID varchar(30),Title varchar(30),ISBN varchar(30),PublisherID varchar(30),PublicationYear date)"
query3 = "create table Publishers(PublisherID varchar(30),Name varchar(30),StreetAddress varchar(30),SuiteNumber varchar(30),ZipCodeID varchar(30))"
query4 = "create table ZipCodes(ZipCodeID varchar(30),City varchar(30),State varchar(30),ZipCode varchar(30))"
query5 = "create table AuthorsTitles(AuthorTitleID varchar(30),AuthorID varchar(30),TitleID varchar(30))"
query6 = "create table Authors(AuthorID varchar(30),FirstName varchar(30),MiddleName varchar(30),LastName varchar(30))"
val = (e1.get(),e2.get())
cursor.execute(query,val)
connection.commit()
queries = [query1,query2,query3,query4,query5,query6]
for query in queries:
cursor.execute(query)
